<?php
phpinfo();

?>

