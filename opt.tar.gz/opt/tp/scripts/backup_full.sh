#!/bin/bash

# Funcion de log
generar_log() {
  local mensaje="$1"
  local timestamp=$(date +"%T")
  echo "$timestamp - $mensaje" >> /var/logs/tp_log.txt
}

# Función de ayuda
mostrar_ayuda() {
    echo "Uso: $0 [-h] -o ORIGEN -d DESTINO"
    echo "Realiza un backup de los directorios de origen a los directorios de destino."
    echo "Opciones:"
    echo "  -h         Mostrar esta ayuda"
    echo "  -o ORIGEN  Directorio de origen"
    echo "  -d DESTINO Directorio de destino"
}


# Validar filesystem
validar() {
	if ! is_no_confirmation_dir "$1" ; then
	 if [ -d "$1" ] ; then
	  # Verificar si el filesystem está montado
	  if ! mountpoint -q "$1"; then
   	  # El filesystem existe pero no está montado
  	  # Preguntar al usuario si desea continuar
	  local response
	  read -r -p "El directorio $1 no esta monstado pero existe. Desea continuar? (y/n): " response
 	   if  ! echo "$response" | grep "^[yY]$" ; then
 	     echo "Operación cancelada por el usuario."
     	     exit 0
	   fi
	  fi
	 else
	  echo "El directorio $1 no existe."
	  exit 1
	 fi
	fi
}

# Lista de directorios que no requieren confirmación
no_confirmation_dirs=("/etc" "/var/logs")

# Función para verificar si un directorio está en la lista de no confirmación
function is_no_confirmation_dir() {
    local dir="$1"
    for no_confirmation_dir in "${no_confirmation_dirs[@]}"; do
        if [ "$dir" == "$no_confirmation_dir" ]; then
            return 0
        fi
    done
    return 1
}

# Variables para almacenar los valores de los argumentos
origen=""
destino=""

# Obtener y validar los argumentos
while getopts "ho:d:" opcion; do
    case "$opcion" in
        h)
            mostrar_ayuda
            exit 0
            ;;
        o)
            origen="$OPTARG"
            ;;
        d)
            destino="$OPTARG"
            ;;
        *)
            mostrar_ayuda >&2
            exit 1
            ;;
    esac
done

# Elimina el ultimo caracter "/" si existe
origen=${origen%/}
destino=${destino%/}

# Verificar si los argumentos están vacíos
if [ -z "$origen" ] || [ -z "$destino" ]; then
    mostrar_ayuda >&2
    exit 1
fi

# Obtener y validar los argumentos
while getopts "ho:d:" opcion; do
    case "$opcion" in
        h)
            mostrar_ayuda
            exit 0
            ;;
        o)
            origen="$OPTARG"
            ;;
        d)
            destino="$OPTARG"
            ;;
        *)
            mostrar_ayuda >&2
            exit 1
            ;;
    esac
done

# Verificar si los filesystems existen y/o estan montados
validar "$origen"
validar "$destino"

echo
echo "----------------------"
echo "---Inicio de BackUp---"
echo "----------------------"
echo 

# Obtener la fecha actual
date=$(date +%Y%m%d)

# Crear una carpeta con el origen y la fecha actual dentro del directorio de destino
mkdir -p "$destino/$(basename "$origen")_bkp_$date"

# Realizar el backup del origen
cp -r $origen "$destino/$(basename "$origen")_bkp_$date"

# Comprimir el backup en un archivo tar.gz
tar -czvf "$destino${origen}_bkp_$date.tar.gz" "$destino/$(basename "$origen")_bkp_$date"

# Eliminar la carpeta de la fecha actual después de comprimir el backup
rm -rf "$destino/$(basename "$origen")_bkp_$date"

# Genero el log del backup finalizado
generar_log "Backup de $origen completado correctamente como $destino/$(basename \"$origen\")_bkp_$date"
# Obtener ultimo registro del archivo log
log=$(tail -n 1 /var/logs/tp_log.txt)
# Envio log por correo electronico del root
echo "$log" | mail -s "Backup" root
