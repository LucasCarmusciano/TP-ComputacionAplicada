#!/bin/bash

# Incluir el archivo esLaborable.sh
source esLaborable.sh

# Verificar que el parametro sea en formato correcto
fecha="^20[0-9]{2}-[0,1][0-9]-[0-2][0-9]$"
if [[ $1 =~ $fecha ]]; then
	esLaborable $1	
else 
	echo "El parametro $1 no tiene el formato de fecha valido (YYYY-MM-DD)"
fi
