#!/bin/bash

# Verifica la existencia de un proceso
ps=`ps -aux | awk '{if ($11~/'$1'/) print $0}'`
if [ -z "$ps" ]; then
	echo "El proceso $1 no existe"
	exit 1
fi

# Identifica (si existe) el proceso en ejecucion
ejec=`ps -aux | awk '{if ($8~/R/) print $0}' | grep $1 | grep -v "{if ('$8'~/R/) print '$0'"`

# Genera un mail al usuario root informando que no se encuentra en ejecucion
if [ -z "$ejec" ]; then
	echo "El proceso $1 existe y no esta en ejecucion"
	echo "El proceso $1 no esta en ejecucion" | mail -s "Proceso no encontrado" root
else
	echo "El proceso $1 existe y esta en ejecucion"
fi	
exit 0
